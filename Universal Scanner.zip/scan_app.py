"""
Simple scanner app (looks like the Epson Scan window).
Works on Windows with any WIA scanner (Epson L3260 included).

v4 - scanner icon (window, taskbar and exe)
v3 - adds an "Advanced Settings" tab (image option, brightness, contrast, gamma, unsharp mask,
     descreening, edge fill)
v2 - better scan quality:
  * default 300 dpi
  * page clean-up: white paper, correct colour cast, sharper text (Document Mode)
  * Black & White uses a local (adaptive) threshold instead of dithering
  * optional "Straighten pages" (deskew)
  * JPEG / PDF saved at high quality (no chroma subsampling) instead of Pillow's default 75
  * B&W pages are stored losslessly in the PDF
  * warns when the scanner did not accept the requested resolution

Install once:
    pip install pywin32 pillow

Run:
    python scan_app.py
"""
import os
import time
import tempfile
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from PIL import Image, ImageChops, ImageDraw, ImageFilter, features

# 64x64 PNG used for the window / taskbar icon (the exe icon comes from scanapp.ico at build time)
ICON_PNG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAARtElEQVR42tWbS29d13XHf2vvfc7lvbx8k6IoyZIoqY6TSLFr5wE0"
    "SACjSNJ20haFgCLNIECRfIgMWqCDzPoF3EkGjidCxmmbIh61SdzGr1iKbT1NvSiK5OV9n9feq4NzSOpFWVRM2jnAgQjh3H3OXs//"
    "+q+1hQeus2fP2nPnznmAkampo1NT8981Yl5G+CIih1AAhM/mpQigegvlfNDweqt157Wk1Vqqdmeh3NvmJQ/s3nLunP/G3/7DQmtl"
    "5V/SQf/vRMwUKKrl/cdwiQgiAiKohpYvip8Vmf+npfd/e/tBIciDmv/GX3//O89/4y9+8sI3/+rgys0lPMariqiqGEFiCygUCkWo"
    "FtjBHlRBBJwBu582U36sunhE8zSzP3/1X7n+4e+WB73u929fPv8fgAU8gNs0jXPnzvmJAws/aIyNvzJ/5CSqUow2x+30qLGjsSUE"
    "SHKlNQyowPgIjNUMqMAOhmEMpIXSTZVerth9NIHgC3FxzEijqXMHj/nlaxcPOjf49+NfePGH1y68+W+bluA2/1g8/dK3hv3eK2KM"
    "F+ckGQ5dLJ5npwzzTcgDbAzh19cLLMLRMcOJacj9ow0gALGBbgaX1z2t1YCYfRMAvshLV4iNRLURJ0IIIaiLzCsLp05fu33p3C84"
    "e9YaOBcWF0/PBx9eVVUN3kvwwYixpR8hWwou3ar0L8EA5Y5UHr7LiATC5vOyucDe35vvFIMieF9QfaxoCOqsvLp4+vQ8584FB2gR"
    "2R87aw+ohgLECWBQulngV9dzYmsQIAtKCKAo7972XFjxmJ09AAAfoAiKNWVM2L8wQBm0VbeClIBR1cLY6ECR+R8D/+gOnzlzhFTP"
    "huBVwBojOGeIIkMtshgRFCEA1grObmtXtYokj7mMgdjIPidOIRiDiwzWGZwtLaKSvw3BK+jZw2fO/LMzuXzPWDumQb0INsk9650M"
    "rQ9J+kPEVCnlD0rO+w0chOA9NlJcpPQTTwhaegcqhOCNdWPk/ntOAy+rUVCwzrF2d4UL73/IdD5J2m0hxiD32PnWZmR3AkD3aqv3"
    "LK3b/6kaMCYCLbjx0WXSZLhtBSIlrgm87IDnK4BjjI3YuHOd4sKb9JvP4tPksbv9LMAi2RTCPZJQDVjrUE0Yrn7E3aWL+GyIIJtg"
    "zlT/Pu9EZL76pSAWTdr41mXo3aQxvoCqR9Ujsu38nzU8+KCOQuFx9VH8sE1n+T0o+mWC2BaAgCIi8+7eMClV1Cr6LdpX/4+5F/6G"
    "EBT1HjFaPSlEVhDZ36j+uI37ECi8likXRVCCzxm0btK+9gbqfZXX9KFc4e6VnaqWAkh6dJfeZuLk14kak6gRVANx5Hju6CTNEfeZ"
    "EIAqRM7QTwpurva5udrHorj6GPlgncHyhxT9dcRYCOGRMnQPF1OCBk/evUv/1nkmT34N60bIkwESCdPNmMlm7TMhAB+gHls2eimr"
    "7SEhKNYoYiOS9ev0b7xX1iOPWcPtVE2pejrXfsvowWepTR4BhLzwrHdSGiMRsTOl2X2KhXEIUIRAd5DR7mUIgoki8qRD/85FhmtX"
    "EetAw4P5YhunPBpBle4wWP6A4cpVQjbARTF5UbB0t88wLapU8ulagDFClgVW2ilrnQRrBBs3SFavMFy9guZpRQ/ojjnLPDK5bQI3"
    "9fRvnyfrreBGmhig1U1Z76YUhcfZT08IqhBFwlo3Yb07xGvAGUWDp7v0DunadcS5j/VTs9Pqqgpi6d2+QH/lCsEXWGvwwXNnfUh3"
    "kOOc+fSsQCB4Zbk1oNPLcS5C4hrJ2nWSu1fxwy5iLKrhKQQApd8Yoei3GK5cIt24ia01MCKsdoasd1NCCBiz/5oHwYrQ6masdzLS"
    "vMCZUhmdpTfJendRwpO50ceU1SCGZO0jBrcugI2wxjJIC1Y7Ce1+hrP7bwUiZUV6e31Af5gjxmAE8u4qvetv49M+Yu0TpanH6y8o"
    "YiLy9h16t96j6LWwRjDG0Ool3NlI/uBC6Wk2D8ogLbjd6pMVBS6uE0JBb/n3ZO1lNOT3or6nF4BqQEQIoSDt3KG3fAGJYuI4YpB4"
    "7rYSkrTAiOxLtRcUnC3TbxmHfIX7DXm/Tffq/6Ih7Eop5uMrOUVEKAYtOlfeoEiHGFVCCHSGKbdbA6QiO0Io4XLYg1u1DEuqSpIV"
    "3FgblJg/qhPyhOHaVYYrl1H8NhnyBJf7+KgTEGMIecpw9SrD1WuMHjiFczWSJOfW2oBDMw1qzhL2MBioQi0yJRjrprQ6CSIeV6uT"
    "rF6hf+s9Qp4gLtpsDnxCArjHFnzap7v0FiOTh3CNabJBynonYXUjYXZyBCsGr7on7lDCXGGjn7G8PiQvfCV0z+DuFQa3PwDrtgmL"
    "J9SFe/LgY0ADvetvMX70BVx9DOMMWR64fLtLPymoRZYi7I0AFMUZw8rGkLsbQ4wB4+qkG3foL18k664gUR0NflfruifsM1RMK+S9"
    "dfrLH1CbWMA2Z8kHHVbbCXfbw6rm3su+V9X7CopBMLUa/Q/Pk6x/hJiqQt3lmk/uArKNp3s33qMxd5KxiYVtJrra+p5igioFlnnf"
    "kQ/a9G9dIGsvg7Fo2P3L3e5UEMA4ktZ1+ssfMDJ3cisHb6bCvRSACAQNIBZjLO2rb5Ju3EB9hrh4p5r/ExLAJhVmhJANGawtEd+5"
    "SH32OHnS28q9e+0CqCLWYYyhe+M9fNpDxCBPSdW5XWtBAzYaIfcF7bvX6LZXwWfsGzGgWjI8YkjzlCBmkwZ+quXc7lywZIvs5BFq"
    "M4uY+iQh6WEjt39MqQghKEFzagdOQdohzzPUpzwNTeWeHIArimDiMeLZRaQ+juYJCvT6/S3qSfcw/pXtdsE5S+wiVMHNniDkCcX6"
    "NZBo14T9LmKAINbi5k5im7OAwRcpxjoWjx0jrtXuYV9kT3CANYYsy9lot+m0O0QGbGMaN3WUkPYIvTXEuEewv3+QACqzMhF2dA43"
    "u4ixMXmWYozl4PwBvvaVF6nX66X17ZkAAs450jTl6kdLvPX2u4RQYFWJJg5CkZJlvYoCf7g40x0aGu5Jxk1UA2akSTT/eUw0gnpP"
    "4T2zU1N8+cUXWFw8Dqp4H/a0PFZVanHM+NgYG60NLl29hs9T4loDmTqMDluk6x8hZbK6zxVCCI8skB4vADFo8JiRMaKpY7jJebTI"
    "GCYJE+NjPPfsSU4cP0a/P6hmAPZ88oUsy4jjmJde+lOWV1ZYXV1nMEiw1uKbR8nu3sSFAeEBRWzOOjxoBu5jmAcwBjt5GDt7DC1y"
    "gi8Q4NjRZ3ju2WfJiwINoWSJnwaL7goEKU6gFsccPjjHN7/+NS5evEx/MCCKawhCcXgc2suoTyhHUsoSffn6Vfrd9sPrPvO5L+kj"
    "/V6A4HFTR4gOfh7bnEfTIXkoOHVika9++SUWjx1lMEwwRvahAa4IhpFYqI9YjBjSLGN9rUVW5Fiz2bssIO2jWpTTLcFTbxh+9cv/"
    "4u3f/Dcbd+9gbURQv5MFbG9Eak2imUVsYxqKfAvrz87MYo1leWWFNM22X76nbJBiRTg0P0mzUScUgWZ9jEMHZjHWoJWPW+tQUxVO"
    "ofzd9IyQpsqtpSXWlm8SxTVCsYMAZDNmmoho7hS2OQ9i8D7FGEMkjkuXr3Dj5s3tfvses6KCEFBUA3/2leeZnXoeVUjSjP5giC9y"
    "fAgIYI3BWltCdu9BA9lgivGJWSYmp/De3xcH3IM1v2pAjMM1Z4lmF0vfztOK/i5f0mqt7z8TbIThMOHkMwtkeU69VsObwK//55dc"
    "ufh7sjTBuQhrHd/887/k6PFTaAh47wkEpuYOMD49gxFDuKdocg/X/YppTBItnEGiBupDOehzT1QVC7LPErDWoqmnnxb0BymjjTq+"
    "CATvSdOUZDjAuRgXxRR5QfCeoIEQAlma0BgdZ3pugebkNFkyeJQAynxvaw2isTmikSYh6ZY0gNwPbswm87GPMnDGYYoBw94G/V4X"
    "Oz9DluY8+9xpDh05Vo3EWKy1HDp8jHq9seWeyWBAXIuYnltgem6e20tXKnyjPNQet24EZx22v4Km5ZDUQ5uVT2FGJoqQbovh6ijd"
    "jTWMPUVQz9HjJ1GFLE3KTCFlbGitr5YA1pQjfiIwPXeAuYOHuHntUhkn7reAagw85JjBBuQ9pCiqoWM+9UtchO23SNfrdNdXthj9"
    "Qb/HpQ8vcPGD81UfsGzclPFMsc7y+dMvMDk7w9TMDHMLR0rc8rAA7tGuNWBjCJvTl7vU/B64h4rFRnXStKDbbhN8gTGWEDy3b93g"
    "nbfewDq3VZAZMXjvESPMzc1z4sSfMDY+xfTcoa1pUtDHQWF9yO61ip6PxfuqaCh5u0+aCLHWkCUp3Xaboii28v6ZL32ZhYUj+KqT"
    "tTWXp2CsYWHhGbxXoqjG3MEFGqNN8iwry+knKwar7CCmbEtXUxT3C6KqtkQw1pbC2swUn0CBVLbALHmR0eu2Saq5vxACM7MHmD1w"
    "kBD8Q4jUGCH4QJ6luChmYnqO2YNHWL5xFcITtMY2NW6jiFpzlFqziYuih61AwThH3GgwMt4kGqmVAXRHnLn7QshYiy8K+v0O6XBA"
    "XKuVwUzKjToX4Zy757YYYzDWYKylNhIxNTPFwjPHMcZuZYGdC3gBDQEbRdTHmjQmJwAYdroM2m18Vram0ZKCiBsNRicnEGfxaUp3"
    "bZ08Se8LIfeFEdnd9KWY0q8H3R4b66tMzUyBCr7Q+8DNVhCqdmasxSgYmxHVAqPN8YrkUnU8rp0gBg0FNnK4Wq3qUEJUi3FRRJFm"
    "W/nUGIuLI4yzhKLAxbWtZzbdJVFIgBgY8UpIAsSm/IIiIAqmbnc+gRICURyzsb7Gz3/2GoePLaKNAwSxmLyPpJ1NrRFGJtHaODYf"
    "UHSWKfIBUWTpbrQ4/+Yb5HmOGCNOVe9U06IPW0L14T4vKIYJrhaDQJ4k+LxKkdUzIXiKNMVnNcQ5sjShyDJElSCCV3jOKc87uJIq"
    "v5uPmX2+yeByQkgCtcMxxkDrjd6OIUNDwAn4bMi1y5dYWm4RJo5DyDCd68hgFVwN4jH82GGIR3HdmyTL74NmVWYoGPb7iqqocscB"
    "74jIt7VMovZhARiC9yT9fhVlIRsk+KJ4KNLnwyF9VWwUkacpRVFgKqv2wAGBrzolZMr5MUvzzChF2+P7nsaJOuKE1m+6VSyVB3wl"
    "oGLQkQk0blIE8LaBDgeY4TokQ3AzqI3AjqFZQAYrxJ079HsdQj5Aq/2IEKQcIXnHieH1UgCPr8WLPKNo59vEp9w/Ri8i+MJTdPtb"
    "mUOqGkIq2LKucL4QbitoPzC4NCRvFYTEk97MUPMx/XFrCbVxdPQATiAWQYarCAO0OV5aQ6Uk0g6Stokj0NExsmGoTo5IOforghpe"
    "l8NnzhwxqVwQI80QPLXGuIw0Z7BRDZ/nT4cEN4+LPXBlVDFAoeYVTQNE5YRv8KUGbM08OjeposaiI5No3ASfYrIBknXK8j0eJ9Rn"
    "EJ8h+QDNukgosC5i2F4jG3YI5eiMIoIG7YWafsF2V1Y6EzMHT1lrXwy+8C6uGxc3MMZsj5vsVgA7OLED6pRH6MQIMmIQK4gTTFTe"
    "O75LBNGA5ANMsoHJeohPK9pLEJ9ikhaS9RCfbHWQRAxFNsDnaQmVFW+ssxr0pzd+/+6rBhCX+x9571fEWKu+CBo8xkXorhj2J+vt"
    "3de+DPcATn1S+CwP3I/Iq7o5/yMVI1xsMsJBrLHB+xWX+x9VqiqPzT3z3Olvibj/FMTH9XEZGZ8xFdf5GTsnK48BDnLftCuqFNmQ"
    "YXcVn2ehLCms1ZB/+/r77/0Czm6e5yyFcPS5Mz8A+4pYSzwyXhhXs2UM++M4MnsfgSolJZYNu1pkAy9inIhBi+KHSxd/t3Vw8l5x"
    "WsAf+dyXviPIT4w1B4Mv0KC+arTsB/X7yQ6TgIoYa6wjeL+s6PdvfPDufUdn7f0/Oms7a69fnJw78priJwRZNNY1xBiRKhpuHZz8"
    "DN/GGBFjxRhrUFqq+lOR9O+vf3D+7VLzF/xjapPt09ULJ75w1MXuu6K8jPBFhT+K4/MCt1DOq/B6kRWv3b5yYcfj8/8P3Gjg7Aew"
    "b5sAAAAASUVORK5CYII="
)

WIA_PNG = "{B96B3CAF-0728-11D3-9D7B-0000F81EF32E}"

# WIA "intent" values
COLOR_INTENT = {"Color": 1, "Grayscale": 2, "Black & White": 4}
GRAY_INTENT = 2

# paper size in inches (width, height)
PAPER = {
    "A4": (8.27, 11.69),
    "A5": (5.83, 8.27),
    "Letter": (8.5, 11.0),
    "Legal": (8.5, 14.0),
}

DESKTOP = os.path.join(os.path.expanduser("~"), "Desktop")
DOCUMENTS = os.path.join(os.path.expanduser("~"), "Documents")
PICTURES = os.path.join(os.path.expanduser("~"), "Pictures")

# output quality choices -> JPEG quality
QUALITY = {"Best (95)": 95, "Good (85)": 85, "Small file (70)": 70}
CLEANUP = ("Auto (recommended)", "Off")
LEVELS = ("Low", "Standard", "High")
EDGE_FILL = ("None", "White", "Black")


# --------------------------------------------------------------------------
# WIA helpers
# --------------------------------------------------------------------------
def list_scanners():
    """Return [(name, device_info), ...] for all WIA scanners."""
    import win32com.client

    mgr = win32com.client.Dispatch("WIA.DeviceManager")
    result = []
    for info in mgr.DeviceInfos:
        if info.Type == 1:  # scanner
            name = "?"
            for p in info.Properties:
                if p.Name == "Name":
                    name = p.Value
            result.append((name, info))
    return result


def set_prop(item, prop_id, value):
    """Set a WIA property by id. Returns True when the scanner accepted it."""
    try:
        item.Properties(prop_id).Value = value
        return True
    except Exception:
        pass
    try:
        for p in item.Properties:
            if p.PropertyID == prop_id:
                p.Value = value
                return True
    except Exception:
        pass
    return False


def get_prop(item, prop_id):
    try:
        return item.Properties(prop_id).Value
    except Exception:
        pass
    try:
        for p in item.Properties:
            if p.PropertyID == prop_id:
                return p.Value
    except Exception:
        pass
    return None


# --------------------------------------------------------------------------
# Image quality
# --------------------------------------------------------------------------
def _percentile(hist, frac):
    total = sum(hist)
    target = total * frac
    acc = 0
    for i, n in enumerate(hist):
        acc += n
        if acc >= target:
            return i
    return len(hist) - 1


def whiten(img):
    """Stretch levels so the paper becomes white and text black.
    RGB pages are balanced per channel, which also removes yellow/blue casts."""
    bands = img.split()
    out = []
    for b in bands:
        h = b.histogram()
        wp = max(_percentile(h, 0.85) * 0.97, 96)
        bp = min(_percentile(h, 0.004), 80)
        if wp - bp < 30:
            out.append(b)
            continue
        scale = 255.0 / (wp - bp)
        lut = [max(0, min(255, int(round((i - bp) * scale)))) for i in range(256)]
        out.append(b.point(lut))
    return Image.merge(img.mode, out)


def sharpen(img, dpi):
    r = max(0.8, 1.3 * dpi / 300.0)
    return img.filter(ImageFilter.UnsharpMask(radius=r, percent=130, threshold=2))


def to_black_white(gray, dpi):
    """Adaptive threshold: keeps thin text and handles shadows / uneven paper."""
    if dpi >= 200:
        gray = gray.filter(ImageFilter.MedianFilter(3))      # removes scanner speckle before thresholding
    radius = max(8, int(dpi / 12))
    bg = gray.filter(ImageFilter.GaussianBlur(radius))
    limit = ImageChops.subtract(bg, Image.new("L", gray.size, 35))
    local = ImageChops.subtract(gray, limit).point(lambda v: 255 if v > 0 else 0)
    solid = gray.point(lambda v: 0 if v < 90 else 255)   # big black areas stay black
    return ImageChops.darker(local, solid)


def estimate_skew(img, max_angle=5.0):
    """Angle (degrees, PIL convention) that straightens the text lines, or 0."""
    g = img.convert("L")
    scale = 900.0 / max(g.size)
    if scale < 1:
        g = g.resize((max(1, int(g.width * scale)), max(1, int(g.height * scale))), Image.BILINEAR)
    dark = g.point(lambda v: 255 if v < 140 else 0)

    def score(a):
        r = dark.rotate(a, resample=Image.BILINEAR, fillcolor=0) if a else dark
        rows = list(r.resize((1, r.height), Image.BOX).getdata())
        m = sum(rows) / len(rows)
        return sum((x - m) ** 2 for x in rows)

    base = score(0.0)
    if base <= 0:
        return 0.0
    best_a, best_s = 0.0, base
    a = -max_angle
    while a <= max_angle + 1e-9:
        s = score(a)
        if s > best_s:
            best_a, best_s = a, s
        a += 0.5
    for k in range(-5, 6):
        a = best_a + k * 0.1
        s = score(a)
        if s > best_s:
            best_a, best_s = a, s
    if abs(best_a) < 0.25 or best_s < base * 1.03:
        return 0.0
    return best_a


def _lut_apply(img, lut):
    return img.point(lut * 3) if img.mode == "RGB" else img.point(lut)


def remove_background(img, level):
    """Push light grey / tinted paper to pure white."""
    t = {"Low": 235, "Standard": 222, "High": 205}[level]
    return _lut_apply(img, [min(255, int(v * 255.0 / t)) for v in range(256)])


def text_enhance(img, level, dpi):
    """Darker text, whiter paper, sharper edges."""
    k = {"Low": 1.25, "Standard": 1.6, "High": 2.1}[level]
    img = _lut_apply(img, [max(0, min(255, int((v - 150) * k + 150))) for v in range(256)])
    return img.filter(ImageFilter.UnsharpMask(radius=max(0.8, 1.2 * dpi / 300.0), percent=150, threshold=2))


def adjust_tone(img, brightness, contrast, gamma):
    """brightness / contrast -100..100 (0 = unchanged), gamma 1.0..3.0 (2.2 = unchanged)."""
    if brightness == 0 and contrast == 0 and abs(gamma - 2.2) < 0.01:
        return img
    c = 1.0 + contrast / 100.0
    b = brightness * 1.275
    e = 2.2 / gamma
    lut = []
    for v in range(256):
        x = 255.0 * ((v / 255.0) ** e)
        x = (x - 128.0) * c + 128.0 + b
        lut.append(max(0, min(255, int(round(x)))))
    return _lut_apply(img, lut)


def edge_fill(img, mode, dpi):
    """Paint a thin border (about 3 mm) white or black to hide scanner-lid shadows."""
    if mode not in ("White", "Black"):
        return img
    w = max(2, int(0.12 * dpi))
    v = 255 if mode == "White" else 0
    col = (v, v, v) if img.mode == "RGB" else v
    out = img.copy()
    d = ImageDraw.Draw(out)
    W, H = out.size
    d.rectangle((0, 0, W - 1, w - 1), fill=col)
    d.rectangle((0, H - w, W - 1, H - 1), fill=col)
    d.rectangle((0, 0, w - 1, H - 1), fill=col)
    d.rectangle((W - w, 0, W - 1, H - 1), fill=col)
    return out


def make_adjust(adv, dpi):
    """Advanced-tab steps that run on the page before it is sharpened / converted to B&W."""
    def run(img):
        if adv["descreen"]:
            img = img.filter(ImageFilter.GaussianBlur(max(0.7, 0.9 * dpi / 300.0)))
        if adv["option"] == "Remove Background":
            img = remove_background(img, adv["bg_level"])
        elif adv["option"] == "Text Enhancement":
            img = text_enhance(img, adv["tx_level"], dpi)
        return adjust_tone(img, adv["brightness"], adv["contrast"], adv["gamma"])
    return run


def finish_page(img, adv, dpi):
    """Advanced-tab steps that run last: extra unsharp mask and edge fill."""
    if adv["unsharp"] and not is_bw(img):
        img = img.filter(ImageFilter.UnsharpMask(radius=max(1.0, 1.5 * dpi / 300.0), percent=150, threshold=2))
    return edge_fill(img, adv["edge"], dpi)


def enhance_page(img, type_name, dpi, document_mode=True, cleanup=True, deskew=False, adjust=None):
    """Clean a scanned page. Returns a PIL image (RGB, L, or L holding pure 0/255 for B&W)."""
    if not cleanup:
        return adjust(img) if adjust else img
    if type_name == "Black & White":
        g = img.convert("L")
        if deskew:
            a = estimate_skew(g)
            if a:
                g = g.rotate(a, resample=Image.BICUBIC, fillcolor=255)
        g = whiten(g)
        if adjust:
            g = adjust(g)
        return to_black_white(g, dpi)
    if deskew:
        a = estimate_skew(img)
        if a:
            img = img.rotate(a, resample=Image.BICUBIC, fillcolor=(255, 255, 255) if img.mode == "RGB" else 255)
    if document_mode:        # photos are left natural
        img = whiten(img)
    if adjust:
        img = adjust(img)
    return sharpen(img, dpi)


# --------------------------------------------------------------------------
# Saving
# --------------------------------------------------------------------------
def is_bw(p):
    """True when the page only contains pure black and white."""
    if p.mode == "1":
        return True
    if p.mode != "L":
        return False
    h = p.histogram()
    return h[0] + h[255] == sum(h)


def unique_path(folder, stem, ext):
    path = os.path.join(folder, stem + ext)
    n = 1
    while os.path.exists(path):
        path = os.path.join(folder, "%s_%d%s" % (stem, n, ext))
        n += 1
    return path


def write_pages(pages, folder, name, fmt, dpi, jpeg_q=95):
    """Save the scanned pages. Returns the path (or the list of paths) written."""
    ext = {"PDF": ".pdf", "JPEG": ".jpg", "PNG": ".png", "TIFF": ".tif"}[fmt]
    os.makedirs(folder, exist_ok=True)
    stem = os.path.splitext(name.strip() or "scan")[0] or "scan"
    dpi = float(dpi)
    dpi_t = (dpi, dpi)

    def prep(p):
        if fmt in ("PDF", "JPEG"):
            if is_bw(p):   # pure black & white: lossless 1-bit (CCITT G4) in the PDF, tiny and razor sharp
                if fmt == "PDF" and features.check("libtiff"):
                    return p.convert("1", dither=Image.Dither.NONE)
                return p.convert("L")
            return p.convert("RGB") if p.mode not in ("RGB", "L") else p
        return p

    if fmt == "PDF":
        pp = [prep(p) for p in pages]
        path = unique_path(folder, stem, ext)
        opts = {"save_all": True, "append_images": pp[1:], "resolution": dpi}
        if all(p.mode == "1" for p in pp):
            pass                                   # CCITT G4: no JPEG options allowed
        else:
            pp = [p.convert("L") if p.mode == "1" else p for p in pp]   # mixed document: JPEG for every page
            opts.update(append_images=pp[1:], quality=jpeg_q, subsampling=0)
        pp[0].save(path, "PDF", **opts)
        return path
    if fmt == "TIFF":
        path = unique_path(folder, stem, ext)
        pages = [p.convert("1", dither=Image.Dither.NONE) if is_bw(p) else p for p in pages]
        comp = "group4" if all(p.mode == "1" for p in pages) else "tiff_adobe_deflate"
        pages[0].save(path, save_all=True, append_images=pages[1:], dpi=dpi_t, compression=comp)
        return path
    paths = []
    for i, p in enumerate(pages, 1):
        s = stem if len(pages) == 1 else "%s_%d" % (stem, i)
        path = unique_path(folder, s, ext)
        if fmt == "JPEG":
            prep(p).save(path, "JPEG", quality=jpeg_q, subsampling=0, optimize=True, dpi=dpi_t)
        else:
            p.save(path, "PNG", optimize=True, dpi=dpi_t)
        paths.append(path)
    return paths[0] if len(paths) == 1 else "\n".join(paths)


# --------------------------------------------------------------------------
# Window
# --------------------------------------------------------------------------
class ScanApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Scan")
        self.resizable(False, False)
        try:    # own taskbar identity so Windows shows the scanner icon, not the Python one
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("ScanApp.Scan")
        except Exception:
            pass
        try:
            self._icon = tk.PhotoImage(data=ICON_PNG_B64)
            self.iconphoto(True, self._icon)      # True = also used by the Add/Save dialog
        except Exception:
            pass
        self.scanners = []
        self.pages = []
        self.page_dpi = 300
        self.warnings = []

        pad = {"padx": 6, "pady": 4}
        nb = ttk.Notebook(self)
        nb.grid(row=0, column=0, padx=8, pady=(8, 0))
        frm = ttk.Frame(nb, padding=12)
        adv = ttk.Frame(nb, padding=12)
        nb.add(frm, text="Main Settings")
        nb.add(adv, text="Advanced Settings")

        r = 0
        ttk.Label(frm, text="Scanner :").grid(row=r, column=0, sticky="e", **pad)
        self.scanner_var = tk.StringVar()
        self.scanner_cb = ttk.Combobox(frm, textvariable=self.scanner_var, state="readonly", width=44)
        self.scanner_cb.grid(row=r, column=1, columnspan=2, sticky="we", **pad)

        r += 1
        ttk.Label(frm, text="Mode :").grid(row=r, column=0, sticky="e", **pad)
        self.mode_var = tk.StringVar(value="Document Mode")
        mf = ttk.Frame(frm)
        mf.grid(row=r, column=1, columnspan=2, sticky="w", **pad)
        ttk.Radiobutton(mf, text="Document Mode", variable=self.mode_var, value="Document Mode").pack(side="left", padx=(0, 12))
        ttk.Radiobutton(mf, text="Photo Mode", variable=self.mode_var, value="Photo Mode").pack(side="left")

        r += 1
        ttk.Separator(frm).grid(row=r, column=0, columnspan=3, sticky="we", pady=6)

        r += 1
        ttk.Label(frm, text="Document Source :").grid(row=r, column=0, sticky="e", **pad)
        self.source_var = tk.StringVar(value="Scanner Glass")
        ttk.Combobox(frm, textvariable=self.source_var, state="readonly", width=20,
                     values=("Scanner Glass", "ADF (Feeder)")).grid(row=r, column=1, sticky="w", **pad)

        r += 1
        ttk.Label(frm, text="Document Size :").grid(row=r, column=0, sticky="e", **pad)
        self.size_var = tk.StringVar(value="A4")
        ttk.Combobox(frm, textvariable=self.size_var, state="readonly", width=20,
                     values=list(PAPER)).grid(row=r, column=1, sticky="w", **pad)

        r += 1
        ttk.Label(frm, text="Image Type :").grid(row=r, column=0, sticky="e", **pad)
        self.type_var = tk.StringVar(value="Color")
        ttk.Combobox(frm, textvariable=self.type_var, state="readonly", width=20,
                     values=list(COLOR_INTENT)).grid(row=r, column=1, sticky="w", **pad)

        r += 1
        ttk.Label(frm, text="Resolution :").grid(row=r, column=0, sticky="e", **pad)
        self.dpi_var = tk.StringVar(value="300")
        rf = ttk.Frame(frm)
        rf.grid(row=r, column=1, sticky="w", **pad)
        ttk.Combobox(rf, textvariable=self.dpi_var, width=8,
                     values=("75", "100", "150", "200", "300", "400", "600")).pack(side="left")
        ttk.Label(rf, text="dpi").pack(side="left", padx=4)

        r += 1
        ttk.Label(frm, text="Rotate :").grid(row=r, column=0, sticky="e", **pad)
        self.rotate_var = tk.StringVar(value="0°")
        ttk.Combobox(frm, textvariable=self.rotate_var, state="readonly", width=8,
                     values=("0°", "90°", "180°", "270°")).grid(row=r, column=1, sticky="w", **pad)

        r += 1
        ttk.Separator(frm).grid(row=r, column=0, columnspan=3, sticky="we", pady=6)

        r += 1
        ttk.Label(frm, text="Clean-up :").grid(row=r, column=0, sticky="e", **pad)
        self.cleanup_var = tk.StringVar(value=CLEANUP[0])
        ttk.Combobox(frm, textvariable=self.cleanup_var, state="readonly", width=20,
                     values=CLEANUP).grid(row=r, column=1, sticky="w", **pad)

        r += 1
        self.deskew_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(frm, text="Straighten pages (deskew)", variable=self.deskew_var).grid(
            row=r, column=1, columnspan=2, sticky="w", **pad)

        r += 1
        self.multi_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(frm, text="Add or edit pages after scanning", variable=self.multi_var).grid(
            row=r, column=1, columnspan=2, sticky="w", **pad)

        r += 1
        ttk.Separator(frm).grid(row=r, column=0, columnspan=3, sticky="we", pady=6)

        r += 1
        ttk.Label(frm, text="Image Format :").grid(row=r, column=0, sticky="e", **pad)
        self.format_var = tk.StringVar(value="PDF")
        ttk.Combobox(frm, textvariable=self.format_var, state="readonly", width=10,
                     values=("PDF", "JPEG", "PNG", "TIFF")).grid(row=r, column=1, sticky="w", **pad)

        r += 1
        ttk.Label(frm, text="File Quality :").grid(row=r, column=0, sticky="e", **pad)
        self.quality_var = tk.StringVar(value="Best (95)")
        ttk.Combobox(frm, textvariable=self.quality_var, state="readonly", width=20,
                     values=list(QUALITY)).grid(row=r, column=1, sticky="w", **pad)

        r += 1
        ttk.Label(frm, text="File Name :").grid(row=r, column=0, sticky="e", **pad)
        self.name_var = tk.StringVar(value="scan")
        ttk.Entry(frm, textvariable=self.name_var, width=30).grid(row=r, column=1, columnspan=2, sticky="w", **pad)

        r += 1
        ttk.Label(frm, text="Folder :").grid(row=r, column=0, sticky="e", **pad)
        self.folder_var = tk.StringVar(value=DESKTOP)
        ttk.Combobox(frm, textvariable=self.folder_var, values=(DESKTOP, DOCUMENTS, PICTURES), width=44).grid(
            row=r, column=1, sticky="w", **pad)
        ttk.Button(frm, text="...", width=3, command=self.browse).grid(row=r, column=2, sticky="w", **pad)

        self.build_advanced(adv)

        btns = ttk.Frame(self)
        btns.grid(row=1, column=0, pady=(6, 12))
        ttk.Button(btns, text="Refresh scanners", command=self.load_scanners).pack(side="left", padx=6)
        ttk.Button(btns, text="Scan", command=self.scan).pack(side="left", padx=6)
        ttk.Button(btns, text="Close", command=self.destroy).pack(side="left", padx=6)

        self.load_scanners()

    # ------------------------------------------------------------------
    def build_advanced(self, adv):
        pad = {"padx": 6, "pady": 4}
        self.opt_var = tk.StringVar(value="None")
        self.bg_level = tk.StringVar(value="Standard")
        self.tx_level = tk.StringVar(value="Standard")
        self.bright_var = tk.DoubleVar(value=0)
        self.contrast_var = tk.DoubleVar(value=0)
        self.gamma_var = tk.DoubleVar(value=2.2)
        self.unsharp_var = tk.BooleanVar(value=False)
        self.descreen_var = tk.BooleanVar(value=False)
        self.edge_var = tk.StringVar(value="None")
        self._updaters = []

        r = 0
        ttk.Label(adv, text="Image Option :").grid(row=r, column=0, sticky="e", **pad)
        ttk.Radiobutton(adv, text="None", variable=self.opt_var, value="None").grid(row=r, column=1, sticky="w", **pad)
        r += 1
        ttk.Radiobutton(adv, text="Remove Background", variable=self.opt_var, value="Remove Background").grid(
            row=r, column=1, sticky="w", **pad)
        ttk.Combobox(adv, textvariable=self.bg_level, state="readonly", width=10, values=LEVELS).grid(
            row=r, column=2, sticky="w", **pad)
        r += 1
        ttk.Radiobutton(adv, text="Text Enhancement", variable=self.opt_var, value="Text Enhancement").grid(
            row=r, column=1, sticky="w", **pad)
        ttk.Combobox(adv, textvariable=self.tx_level, state="readonly", width=10, values=LEVELS).grid(
            row=r, column=2, sticky="w", **pad)
        r += 1
        ttk.Radiobutton(adv, text="Auto Area Segmentation", value="auto", state="disabled").grid(
            row=r, column=1, sticky="w", **pad)
        r += 1
        ttk.Radiobutton(adv, text="Color Enhance", value="color", state="disabled").grid(
            row=r, column=1, sticky="w", **pad)
        ttk.Combobox(adv, state="disabled", width=10, values=("Red",)).grid(row=r, column=2, sticky="w", **pad)

        def slider(row, label, var, lo, hi, decimals):
            ttk.Label(adv, text=label).grid(row=row, column=0, sticky="e", **pad)
            value = ttk.Label(adv, width=5, anchor="e")

            def update(_=None):
                x = round(float(var.get()), decimals)
                var.set(x)
                value.config(text=("%.1f" % x) if decimals else str(int(x)))

            ttk.Scale(adv, from_=lo, to=hi, orient="horizontal", length=210, variable=var, command=update).grid(
                row=row, column=1, sticky="w", **pad)
            value.grid(row=row, column=2, sticky="w", **pad)
            update()
            self._updaters.append(update)

        r += 1
        slider(r, "Brightness :", self.bright_var, -100, 100, 0)
        r += 1
        slider(r, "Contrast :", self.contrast_var, -100, 100, 0)
        r += 1
        slider(r, "Gamma :", self.gamma_var, 1.0, 3.0, 1)

        r += 1
        ttk.Checkbutton(adv, text="Unsharp Mask", variable=self.unsharp_var).grid(row=r, column=1, sticky="w", **pad)
        r += 1
        ttk.Checkbutton(adv, text="Descreening", variable=self.descreen_var).grid(row=r, column=1, sticky="w", **pad)

        r += 1
        ttk.Label(adv, text="Edge Fill :").grid(row=r, column=0, sticky="e", **pad)
        ttk.Combobox(adv, textvariable=self.edge_var, state="readonly", width=14, values=EDGE_FILL).grid(
            row=r, column=1, sticky="w", **pad)
        r += 1
        ttk.Label(adv, text="Dual Image Output :").grid(row=r, column=0, sticky="e", **pad)
        ttk.Combobox(adv, state="disabled", width=14, values=("Off",)).grid(row=r, column=1, sticky="w", **pad)
        r += 1
        ttk.Label(adv, text="Watermark :").grid(row=r, column=0, sticky="e", **pad)
        ttk.Combobox(adv, state="disabled", width=14, values=("Off",)).grid(row=r, column=1, sticky="w", **pad)

        r += 1
        ttk.Button(adv, text="Reset", command=self.reset_advanced).grid(row=r, column=1, sticky="w", **pad)

    def reset_advanced(self):
        self.opt_var.set("None")
        self.bg_level.set("Standard")
        self.tx_level.set("Standard")
        self.bright_var.set(0)
        self.contrast_var.set(0)
        self.gamma_var.set(2.2)
        self.unsharp_var.set(False)
        self.descreen_var.set(False)
        self.edge_var.set("None")
        for u in self._updaters:
            u()

    def adv_settings(self):
        return {
            "option": self.opt_var.get(), "bg_level": self.bg_level.get(), "tx_level": self.tx_level.get(),
            "brightness": int(round(self.bright_var.get())), "contrast": int(round(self.contrast_var.get())),
            "gamma": round(float(self.gamma_var.get()), 1),
            "unsharp": bool(self.unsharp_var.get()), "descreen": bool(self.descreen_var.get()),
            "edge": self.edge_var.get(),
        }

    def browse(self):
        folder = filedialog.askdirectory(initialdir=self.folder_var.get())
        if folder:
            self.folder_var.set(folder)

    def load_scanners(self):
        try:
            self.scanners = list_scanners()
        except Exception as e:
            messagebox.showerror("Error", "Could not list scanners:\n" + str(e))
            self.scanners = []
        names = [n for n, _ in self.scanners]
        self.scanner_cb["values"] = names
        if names and self.scanner_var.get() not in names:
            self.scanner_var.set(names[0])

    # ------------------------------------------------------------------
    def scan_one_page(self):
        name = self.scanner_var.get()
        info = next((i for n, i in self.scanners if n == name), None)
        if info is None:
            raise RuntimeError("No scanner selected.")
        device = info.Connect()
        item = device.Items(1)

        dpi = int(self.dpi_var.get())
        w_in, h_in = PAPER[self.size_var.get()]
        type_name = self.type_var.get()
        cleanup = self.cleanup_var.get() == CLEANUP[0]

        # order matters: intent first (it resets resolution / area), then resolution, then area.
        # With clean-up on, B&W is scanned in grey and thresholded here (much sharper than the
        # scanner's own 1-bit mode).
        intent = GRAY_INTENT if (type_name == "Black & White" and cleanup) else COLOR_INTENT[type_name]
        set_prop(item, 6146, intent)
        set_prop(item, 6147, dpi)
        set_prop(item, 6148, dpi)
        set_prop(item, 6149, 0)
        set_prop(item, 6150, 0)
        set_prop(item, 6151, int(w_in * dpi))
        set_prop(item, 6152, int(h_in * dpi))

        got = get_prop(item, 6147)
        if isinstance(got, (int, float)) and int(got) != dpi:
            self.warnings.append("The scanner used %d dpi instead of %d dpi." % (int(got), dpi))

        img = item.Transfer(WIA_PNG)
        tmp = os.path.join(tempfile.gettempdir(), "wia_scan_tmp.png")
        if os.path.exists(tmp):
            os.remove(tmp)
        img.SaveFile(tmp)
        pil = Image.open(tmp)
        pil.load()
        real = pil.info.get("dpi")
        self.page_dpi = int(round(real[0])) if real and real[0] > 1 else dpi
        try:
            os.remove(tmp)
        except OSError:
            pass

        if type_name == "Color":
            pil = pil.convert("RGB")
        else:
            pil = pil.convert("L")

        angle = int(self.rotate_var.get().replace("°", ""))
        if angle:
            pil = pil.rotate(angle, expand=True)

        adv = self.adv_settings()
        page = enhance_page(pil, type_name, self.page_dpi,
                            document_mode=self.mode_var.get() == "Document Mode",
                            cleanup=cleanup, deskew=self.deskew_var.get(),
                            adjust=make_adjust(adv, self.page_dpi))
        return finish_page(page, adv, self.page_dpi)

    def ask_add_or_save(self, count):
        """Show a dialog with 'Add' and 'Save'. Returns True for Add, False for Save."""
        result = {"add": False}
        dlg = tk.Toplevel(self)
        dlg.title("Scan")
        dlg.resizable(False, False)
        dlg.transient(self)
        dlg.grab_set()
        ttk.Label(dlg, text="%d page(s) scanned.\n\nPut the next page on the glass and click Add to scan it,\n"
                            "or click Save to finish and save." % count,
                  padding=(10, 12), justify="left").pack()
        row = ttk.Frame(dlg, padding=(10, 0, 10, 12))
        row.pack(anchor="e")

        def choose(add):
            result["add"] = add
            dlg.destroy()

        add_btn = ttk.Button(row, text="Add", width=10, command=lambda: choose(True))
        add_btn.pack(side="left", padx=6)
        ttk.Button(row, text="Save", width=10, command=lambda: choose(False)).pack(side="left", padx=6)
        add_btn.focus_set()
        dlg.bind("<Return>", lambda e: choose(True))
        dlg.protocol("WM_DELETE_WINDOW", lambda: choose(False))
        dlg.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - dlg.winfo_width()) // 2
        y = self.winfo_y() + (self.winfo_height() - dlg.winfo_height()) // 2
        dlg.geometry("+%d+%d" % (max(x, 0), max(y, 0)))
        self.wait_window(dlg)
        return result["add"]

    def scan_with_retry(self, tries=4, wait=4):
        """Retry when the scanner reports 'busy' (e.g. still warming up)."""
        for attempt in range(tries):
            try:
                return self.scan_one_page()
            except Exception as e:
                busy = "busy" in str(e).lower()
                if busy and attempt < tries - 1:
                    time.sleep(wait)
                    continue
                if busy:
                    raise RuntimeError(
                        "The scanner is busy.\n\nClose Epson Scan, Windows Fax and Scan, and any other "
                        "scanning program, then turn the scanner off and on and try again.")
                raise

    def save_pages(self):
        return write_pages(self.pages, self.folder_var.get(), self.name_var.get(), self.format_var.get(),
                           self.page_dpi, QUALITY.get(self.quality_var.get(), 95))

    def scan(self):
        self.pages = []
        self.warnings = []
        self.config(cursor="watch")
        self.update()
        try:
            while True:
                self.pages.append(self.scan_with_retry())
                self.config(cursor="")
                more = self.multi_var.get() and self.ask_add_or_save(len(self.pages))
                if not more:
                    break
                self.config(cursor="watch")
                self.update()
            self.config(cursor="watch")
            self.update()
            path = self.save_pages()
            msg = "Saved:\n" + path
            if self.warnings:
                msg += "\n\n" + "\n".join(sorted(set(self.warnings)))
            messagebox.showinfo("Done", msg)
        except Exception as e:
            messagebox.showerror("Scan failed", str(e))
        finally:
            self.config(cursor="")


if __name__ == "__main__":
    ScanApp().mainloop()
