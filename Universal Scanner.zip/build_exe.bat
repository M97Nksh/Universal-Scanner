@echo off
cd /d "%~dp0"

if not exist scan_app.py (
    echo ERROR: scan_app.py is not in this folder.
    pause
    exit /b
)

echo Installing libraries...
py -m pip install pillow pywin32 pyinstaller

echo.
echo Making icon...
if exist scan_icon.ico del /q scan_icon.ico
py make_icon.py
if not exist scan_icon.ico (
    echo ERROR: could not create scan_icon.ico. Put make_icon.py next to this file.
    pause
    exit /b
)

echo.
echo Removing old build files...
rmdir /s /q build 2>nul
rmdir /s /q dist 2>nul
del /q ScanApp.spec 2>nul

echo.
echo Building ScanApp.exe with icon ...
py -m PyInstaller --clean --onefile --noconsole --icon "%~dp0scan_icon.ico" --hidden-import win32timezone --name ScanApp scan_app.py

echo.
echo Refreshing Windows icon cache...
ie4uinit.exe -show

echo.
echo Done. Your exe is in the "dist" folder: dist\ScanApp.exe
pause
