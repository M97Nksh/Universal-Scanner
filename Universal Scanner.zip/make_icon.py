"""Creates scan_icon.ico from the icon embedded in scan_app.py."""
import base64
import io
import re

from PIL import Image

src = open("scan_app.py", encoding="utf-8").read()
m = re.search(r"ICON_PNG_B64 = \((.*?)\)\n", src, re.S)
b64 = "".join(re.findall(r'"([A-Za-z0-9+/=]+)"', m.group(1)))
im = Image.open(io.BytesIO(base64.b64decode(b64))).convert("RGBA")
im.save("scan_icon.ico", sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128)])
print("scan_icon.ico created")
